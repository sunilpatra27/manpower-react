import React,{Component} from 'react';

class Aboutus extends Component{

render(){

    return(
        <div>
           <div className="container about_bg">
                <div className="row">
                    <div className="col-lg-7 col-md-6">
                        <div className="about_content">
                            <h2>Welcome to Our Company</h2>
                            <h3>Aliquam lacus purus, auctor malesuada</h3>
                            <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit,</p>
                            <p>sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? </p>
                            <a href="/" className="btn know_btn">know more</a>
                        </div>
                    </div>
                    <div className="col-lg-3 col-md-6 col-lg-offset-1">
                        <div className="about_banner">
                            <img src={require("../../Assets/images/man.png")} alt=""/>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

}


export default Aboutus;