import React,{Component} from 'react';



class CustomerReview extends Component{
    render(){

        return(


            <div className="container text-center testimonial_area">
                <h2>Customer Reviews</h2>
                <p>For no one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because they do not know how to pursue pleasure rationally encounter consequences that are the sorrows of those who have. Nor is there any person belonging, and their distressing anguish alone, that it dolor sit amet, consectetur, he wishes to obtain,</p>

                <div className="row">
                    <div className="col-md-4">
                        <div className="testimonial_item">
                            <div className="testimonial_content text-left">
                                <p>For no one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because they do not know how to pursue pleasure rationally encounter consequences that are the sorrows of those who have. Nor is there any person belonging, and their distressing anguish alone, that it dolor sit amet, consectetur, he wishes to obtain,,</p>
                            </div>
                            <img src={require("../../Assets/images/testimonial_img1.png")} alt="Testimonial"/>
                            <p className="worker_name">Sunil Patra</p>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <div className="testimonial_item">
                            <div className="testimonial_content">
                                <p>For no one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because they do not know how to pursue pleasure rationally encounter consequences that are the sorrows of those who have. Nor is there any person belonging, and their distressing anguish alone, that it dolor sit amet, consectetur, he wishes to obtain,,</p>
                            </div>
                            <img src={require("../../Assets/images/testimonial_img2.png")} alt="Testimonial"/>
                            <p className="worker_name">Sunil Patra</p>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <div className="testimonial_item">
                            <div className="testimonial_content">
                                <p>For no one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because they do not know how to pursue pleasure rationally encounter consequences that are the sorrows of those who have. Nor is there any person belonging, and their distressing anguish alone, that it dolor sit amet, consectetur, he wishes to obtain,,</p>
                            </div>
                            <img src={require("../../Assets/images/testimonial_img1.png")} alt="Testimonial"/>
                            <p className="worker_name">Sunil Patra</p>
                        </div>
                    </div>
                </div>
            </div>
   

        )
    }
}




export default CustomerReview;