import React from 'react';
import {Link} from 'react-router-dom';




const navbar=()=>(


    <div>

        <nav className={["navbar","bootsnav","on" ,"no-full"].join(' ')}>
       
              
                {/* <div className="top-search">
                    <div className="container">
                        <div className="input-group">
                            <span className="input-group-addon"><i className={["fa" ,"fa-search"].join('  ')}></i></span>
                            <input type="text" className="form-control" placeholder="Search"/>
                            <span className={["input-group-addon" ,"close-search"].join(' ')}><i className={["fa", "fa-times"].join(' ')}></i></span>
                        </div>
                    </div>
                </div> */}

                <div className={"container"}>
                   
                    {/* <div className="attr-nav">
                        <ul>
                            <li className="search"><a href="#"><i className={["fa","fa-search"].join(' ')}></i></a></li>
                        </ul>
                    </div>
                   
                    <div className="navbar-header">
                        <button type="button" className="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                            <i className={["fa","fa-bars"].join(' ')}></i>
                        </button>
                        <a className="navbar-brand" href=""><img className="logo" src="images/logo.png" alt=""/></a>
                    </div> */}

                    <div className={["collapse","navbar-collapse"].join(' ')} id="navbar-menu">
                        <ul className={["nav" ,"navbar-nav", "menu"].join(' ')}>
                            <li><Link to="/home">Home</Link></li>                    
                            <li><Link to="/contactus">Contact Us</Link></li>
                            <li><Link to="/whyus">Why Us</Link></li>
                            <li><Link to="#portfolio">Portfolio</Link></li>
                            <li><Link to="/customerreview">Customer Review</Link></li>
                        </ul>
                    </div>
                </div>   
            </nav>
    
    </div>
)



export default navbar;