import React from 'react';

import classes from './Header.module.css';

const header=()=>(
<div className={classes.Header}>

    <div className={classes.HeaderContent}>

    <span className={["fa","fa-phone"].join(' ')}></span>


{"+91-132-7878124"}
    </div>

<div className={classes.HeaderContent}>
<span className={["fa","fa-envelope"].join(' ')}></span>

{"man-power-support@here.com"}

</div>
<div className={classes.HeaderContent}>
<span className={["fa","fa-clock-o"].join(' ')}></span>
{" Mon - Sat 9:00 - 19:00"}

</div>

<div className={classes.HeaderContent}>
<span className={["fa","fa-facebook"].join(' ')}></span>
</div>

<div className={classes.HeaderContent}>
<span className={["fa","fa-twitter"].join(' ')}></span>
</div>

<div className={classes.HeaderContent}>
<span className={["fa","fa-behance"].join(' ')}></span>
</div>


<div className={classes.HeaderContent}>
<span className={["fa","fa-dribbble"].join(' ')}></span>
</div>

<div className={classes.HeaderContent}>
<span className={["fa","fa-linkedin"].join(' ')}></span>
</div>

<div className={classes.HeaderContent}>
<span className={["fa","fa-youtube"].join(' ')}></span>
</div>


</div>

 


);




export default header;
