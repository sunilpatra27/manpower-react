import React, { Component } from 'react';
import {Route,Switch,Redirect} from 'react-router-dom';
import Header from '../Header/Header';
import Navbar from '../Navbar/Navbar';
import Whyus from '../Whyus/Whyus';
import Contactus from '../Contactus/Contactus';
import Aboutus from '../Aboutus/Aboutus';
import Customerreview from '../CustomerReview/CustomerReview'
class Home extends Component{


render(){



    return(


        <div>

       
        <Header/>
        <Navbar/>
    


        <Switch>
    <Route path="/home" exact component={Aboutus}/>
    <Route path="/contactus" exact component={Contactus}/>
    <Route path="/whyus" exact component={Whyus}/>
    <Route path ="/customerreview" exact component={Customerreview}/>
    <Redirect from="" to="/home"/>
    </Switch>
        </div>
    )
}






}







export default Home
