import React,{Component} from 'react';

class Contactus extends Component{

render(){

    return(
        <div>
           
            <div className="container">
                <div className="row">
                    <div className="col-md-6">
                        <h2>Do you have any questions?</h2>
                        <h2 className="second_heading">Feel free to contact us!</h2>
                    </div>
                   
                </div>
            </div>
     
        </div>
    )
}

}


export default Contactus;
