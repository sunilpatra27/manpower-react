import React from 'react';
const whyUs=()=>(
    <div>


<section id="why_us">
            <div className={["container" ,"text-center"].join(' ')}>
                <div className="row">
                    <div className={["col-md-8","col-md-offset-2"].join(' ')}>
                        <div className="head_title">
                            <h2>WHY CHOOSE US?</h2>
                            <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit,</p>

                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className={["col-md-3", "col-sm-6"].join(' ')}>
                        <div className="why_us_item">
                            <span className="fa fa-leaf"></span>
                            <h4>We deliver quality</h4>
                            <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni </p>
                        </div>
                    </div>
                    <div className={["col-md-3", "col-sm-6"].join(' ')}>
                        <div className="why_us_item">
                            <span className="fa fa-futbol-o"></span>
                            <h4>Always on time</h4>
                            <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni</p>
                        </div>
                    </div>
                    <div className={["col-md-3", "col-sm-6"].join(' ')}>
                        <div className="why_us_item">
                            <span className="fa fa-group"></span>
                            <h4>We are pasionate</h4>
                            <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni</p>
                        </div>
                    </div>
                    <div className={["col-md-3", "col-sm-6"].join(' ')}>
                        <div className="why_us_item">
                            <span className="fa fa-line-chart"></span>
                            <h4>Professional Services</h4>
                            <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
)

export default whyUs;